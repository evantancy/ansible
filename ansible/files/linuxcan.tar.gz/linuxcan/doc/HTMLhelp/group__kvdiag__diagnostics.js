var group__kvdiag__diagnostics =
[
    [ "kvDiagConfigure", "group__kvdiag__diagnostics.html#gab4372ea63d7ccbd231f7aad43fa4ca41", null ],
    [ "kvDiagGetAnalyzerInfo", "group__kvdiag__diagnostics.html#ga51f35afc5932e36d769c0bc6358a5d51", null ],
    [ "kvDiagGetNumberOfAnalyzers", "group__kvdiag__diagnostics.html#ga886b47550df183e143c3e97f4d4be0d4", null ],
    [ "kvDiagReadSampleRaw", "group__kvdiag__diagnostics.html#gabee84d93ebb0e659c68e6a68eee354c3", null ],
    [ "kvDiagStart", "group__kvdiag__diagnostics.html#ga663a7dc925d0a4e49a9d85cbe59db917", null ],
    [ "kvDiagStop", "group__kvdiag__diagnostics.html#ga9cd97a8c629f875b97948f5e954274d9", null ]
];
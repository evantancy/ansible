var bus__params__tq_8h =
[
    [ "kvBusParamsTq", "structkv_bus_params_tq.html", "structkv_bus_params_tq" ],
    [ "kvBusParamsTq", "bus__params__tq_8h.html#a55095b4ff633151ac4ccf06b1f3df1da", null ]
];
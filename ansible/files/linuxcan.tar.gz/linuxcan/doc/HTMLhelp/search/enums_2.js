var searchData=
[
  ['linstatus',['LinStatus',['../group__lin__status__codes.html#ga7a5ecfd2846ddd76cd49fb4edec7fc14',1,'linlib.h']]]
];

var searchData=
[
  ['diagdataptr',['DiagDataPtr',['../kv_diag_8h.html#addaade3120c38728f2742813f48f2684',1,'kvDiag.h']]],
  ['dword',['DWORD',['../linlib_8h.html#a798af1e30bc65f319c1a246cecf59e39',1,'linlib.h']]]
];

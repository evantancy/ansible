var group__grp__kvdiag =
[
    [ "Setup", "group__kvdiag__setup.html", "group__kvdiag__setup" ],
    [ "Diagnostics", "group__kvdiag__diagnostics.html", "group__kvdiag__diagnostics" ]
];
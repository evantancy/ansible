var kv_diag_8h =
[
    [ "DIAG_ANALYZER_TYPE_DEFAULT", "kv_diag_8h.html#a29188edd320816f6f3b4e98e6b331a66", null ],
    [ "KDI_DEFAULT_MAX_SAMPLE_SIZE", "kv_diag_8h.html#a37907e79fc7ecbe5e0e7481b9223c780", null ],
    [ "DiagDataPtr", "kv_diag_8h.html#addaade3120c38728f2742813f48f2684", null ],
    [ "kvDiagAlloc", "group__kvdiag__setup.html#ga28b98f7100fa0bb9cb23e5848c10940d", null ],
    [ "kvDiagAttach", "group__kvdiag__setup.html#gabea2d51b6e961ba21e9c62ea24d6621f", null ],
    [ "kvDiagConfigure", "group__kvdiag__diagnostics.html#gab4372ea63d7ccbd231f7aad43fa4ca41", null ],
    [ "kvDiagDealloc", "group__kvdiag__setup.html#ga2a6950ff605deae5dfb7cba70e883e00", null ],
    [ "kvDiagDetach", "group__kvdiag__setup.html#ga8f1f2a2caca8b798987fa1f24147bccf", null ],
    [ "kvDiagGetAnalyzerInfo", "group__kvdiag__diagnostics.html#ga51f35afc5932e36d769c0bc6358a5d51", null ],
    [ "kvDiagGetNumberOfAnalyzers", "group__kvdiag__diagnostics.html#ga886b47550df183e143c3e97f4d4be0d4", null ],
    [ "kvDiagReadSampleRaw", "group__kvdiag__diagnostics.html#gabee84d93ebb0e659c68e6a68eee354c3", null ],
    [ "kvDiagStart", "group__kvdiag__diagnostics.html#ga663a7dc925d0a4e49a9d85cbe59db917", null ],
    [ "kvDiagStop", "group__kvdiag__diagnostics.html#ga9cd97a8c629f875b97948f5e954274d9", null ]
];